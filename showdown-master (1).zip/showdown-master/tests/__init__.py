import logging

logging.disable(logging.CRITICAL)
